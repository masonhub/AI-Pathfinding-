﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerController : MonoBehaviour
{
    public float Speed;
    
    private Rigidbody2D _PlayerRigidbody;
   
    private float _MoveHorizontal;
    private float _MoveVertical;

    // Start is called before the first frame update
    void Start()
    {
        _PlayerRigidbody = GetComponent<Rigidbody2D>();
    }
    void FixedUpdate() // fixed ammount
    {
        _MoveHorizontal = Input.GetAxis("Horizontal");
        _MoveVertical = Input.GetAxis("Vertical");

        //this gives us the direction the player is moving
        Vector2 movement = new Vector2(_MoveHorizontal, _MoveVertical);

        _PlayerRigidbody.AddForce(movement * Speed);

    }
}