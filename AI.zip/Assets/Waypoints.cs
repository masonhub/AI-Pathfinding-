﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Waypoints : MonoBehaviour
{ 
    public float Speed = 5.0f;
    public GameObject[] Waypoint;
    public GameObject AiSprite;
    public float MinDistanceToWaypoint;
    public GameObject playerObject;
    public float ChasePlayerDistance;
    private int CurrentWaypoint = 0;

    void Update()
    {
        if (Vector2.Distance(playerObject.transform.position,
                     AiSprite.transform.position)
                   < ChasePlayerDistance)
        {
            MoveAi(playerObject.transform.position);
        }
        else
        {
            Patrol();
        }
    }



    private void Patrol()
    {
        float distance = Vector2.Distance(AiSprite.transform.position, Waypoint[CurrentWaypoint].transform.position);
        //Are we at the target location
        if (distance < MinDistanceToWaypoint)
        {
            CurrentWaypoint++;
        }

        //if we reached the last waypoint, start again
        if (CurrentWaypoint >= Waypoint.Length)
        {
            CurrentWaypoint = 0;
        }


        MoveAi(Waypoint[CurrentWaypoint].transform.position);

    }



    private void MoveAi(Vector2 targetPosition)
    {
        //move ai
        AiSprite.transform.position = Vector2.MoveTowards(AiSprite.transform.position,
                                                        targetPosition,
                                                            Speed * Time.deltaTime);
    }







}
// 
//public GameObject Player;
//public float ChasePlayerDistance;
/*
 *         //if close enough chase player
        if (Vector2.Distance(Player.transform.position,
                             AiSprite.transform.position)
                           < ChasePlayerDistance)
        {
           

            MoveAI(Player.transform.position);
        }
        else // <-------
        {
            Patrol();
        }
*/
